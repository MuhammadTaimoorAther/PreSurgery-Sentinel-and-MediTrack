function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.getElementById('main-content');
  const overlay = document.getElementById('overlay');
  sidebar.classList.toggle('open');
  overlay.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
  // Adjust main content margin right when the sidebar is open
  mainContent.style.marginRight = sidebar.classList.contains('open') ? '250px' : '0';
}

function handleReportSelect(reportName) {
  console.log("Selected report:", reportName); // Add this line for debugging
  const uploadForm = document.getElementById('uploadForm');
  const formTitle = document.getElementById('formTitle');
  const fileInput = document.getElementById('fileUpload');
  const reportNameInput = document.getElementById('reportName');
  reportNameInput.value = reportName;
  if (reportName === 'Activated Partial Thromboplastin Time (aPTT)' ||
      reportName === 'C-reactive protein (CRP)' ||
      reportName === 'Erythrocyte Sedimentation Rate(ESR)' ||
      reportName === 'Hepatitis B' ||
      reportName === 'Hepatitis C' ||
      reportName === 'Liver Function Test(LFT)' ||
      reportName === 'Renal Function Test (RFT)' ||
      reportName === 'Serum Electrolytes' ||
      reportName === 'Sugar(BSR)' ||
      reportName === 'Creatinine Serum(URE)') ||
      reportName === 'Complete Blood Count(CBC)'{

    uploadForm.style.display = 'block';
    formTitle.innerText = 'Upload Report for ' + reportName;
    // Set a custom attribute on the file input to store the selected report name
    fileInput.setAttribute('data-report-name', reportName);
    // Set the value of the hidden input field to the selected report name
    reportNameInput.value = reportName;
  } else {
    uploadForm.style.display = 'none';
  }
}

function addFileInput() {
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.name = 'fileUpload';
  fileInput.accept = '.jpg, .jpeg, .png';
  // Append the new file input to the form
  document.getElementById('uploadForm').appendChild(fileInput);
}


